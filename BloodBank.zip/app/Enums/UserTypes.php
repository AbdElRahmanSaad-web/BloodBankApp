<?php

namespace App\Enums;

class UserTypes
{
    const Donor = 'Donor';
    const Hospital = 'Hospital';
    const BloodBank = 'BloodBank';
    const Recipient = 'Recipient';
}
